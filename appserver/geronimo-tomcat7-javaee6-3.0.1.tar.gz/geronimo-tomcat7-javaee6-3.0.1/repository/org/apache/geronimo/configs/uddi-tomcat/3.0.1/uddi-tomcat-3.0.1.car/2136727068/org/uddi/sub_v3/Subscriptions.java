
package org.uddi.sub_v3;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "subscriptions", namespace = "urn:uddi-org:sub_v3")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "subscriptions", namespace = "urn:uddi-org:sub_v3")
public class Subscriptions {

    @XmlElement(name = "subscription", namespace = "urn:uddi-org:sub_v3")
    private List<org.uddi.sub_v3.Subscription> subscription;

    /**
     * 
     * @return
     *     returns List<Subscription>
     */
    public List<org.uddi.sub_v3.Subscription> getSubscription() {
        return this.subscription;
    }

    /**
     * 
     * @param subscription
     *     the value for the subscription property
     */
    public void setSubscription(List<org.uddi.sub_v3.Subscription> subscription) {
        this.subscription = subscription;
    }

}

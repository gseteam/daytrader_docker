
package org.uddi.custody_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

@XmlRootElement(name = "transferToken", namespace = "urn:uddi-org:custody_v3")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "transferToken", namespace = "urn:uddi-org:custody_v3", propOrder = {
    "nodeID",
    "expirationTime",
    "opaqueToken"
})
public class TransferToken {

    @XmlElement(name = "nodeID", namespace = "urn:uddi-org:api_v3")
    private String nodeID;
    @XmlElement(name = "expirationTime", namespace = "urn:uddi-org:custody_v3")
    private XMLGregorianCalendar expirationTime;
    @XmlElement(name = "opaqueToken", namespace = "urn:uddi-org:custody_v3", nillable = true)
    private byte[] opaqueToken;

    /**
     * 
     * @return
     *     returns String
     */
    public String getNodeID() {
        return this.nodeID;
    }

    /**
     * 
     * @param nodeID
     *     the value for the nodeID property
     */
    public void setNodeID(String nodeID) {
        this.nodeID = nodeID;
    }

    /**
     * 
     * @return
     *     returns XMLGregorianCalendar
     */
    public XMLGregorianCalendar getExpirationTime() {
        return this.expirationTime;
    }

    /**
     * 
     * @param expirationTime
     *     the value for the expirationTime property
     */
    public void setExpirationTime(XMLGregorianCalendar expirationTime) {
        this.expirationTime = expirationTime;
    }

    /**
     * 
     * @return
     *     returns byte[]
     */
    public byte[] getOpaqueToken() {
        return this.opaqueToken;
    }

    /**
     * 
     * @param opaqueToken
     *     the value for the opaqueToken property
     */
    public void setOpaqueToken(byte[] opaqueToken) {
        this.opaqueToken = opaqueToken;
    }

}


package org.uddi.api_v3;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "set_publisherAssertions", namespace = "urn:uddi-org:api_v3")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "set_publisherAssertions", namespace = "urn:uddi-org:api_v3", propOrder = {
    "authInfo",
    "publisherAssertion"
})
public class SetPublisherAssertions {

    @XmlElement(name = "authInfo", namespace = "urn:uddi-org:api_v3")
    private String authInfo;
    @XmlElement(name = "publisherAssertion", namespace = "urn:uddi-org:api_v3")
    private List<org.uddi.api_v3.PublisherAssertion> publisherAssertion;

    /**
     * 
     * @return
     *     returns String
     */
    public String getAuthInfo() {
        return this.authInfo;
    }

    /**
     * 
     * @param authInfo
     *     the value for the authInfo property
     */
    public void setAuthInfo(String authInfo) {
        this.authInfo = authInfo;
    }

    /**
     * 
     * @return
     *     returns List<PublisherAssertion>
     */
    public List<org.uddi.api_v3.PublisherAssertion> getPublisherAssertion() {
        return this.publisherAssertion;
    }

    /**
     * 
     * @param publisherAssertion
     *     the value for the publisherAssertion property
     */
    public void setPublisherAssertion(List<org.uddi.api_v3.PublisherAssertion> publisherAssertion) {
        this.publisherAssertion = publisherAssertion;
    }

}

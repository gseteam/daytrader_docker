
package org.uddi.custody_v3;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "get_transferToken", namespace = "urn:uddi-org:custody_v3")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "get_transferToken", namespace = "urn:uddi-org:custody_v3", propOrder = {
    "authInfo",
    "keyBag"
})
public class GetTransferToken {

    @XmlElement(name = "authInfo", namespace = "urn:uddi-org:api_v3")
    private String authInfo;
    @XmlElement(name = "keyBag", namespace = "urn:uddi-org:custody_v3")
    private org.uddi.custody_v3.KeyBag keyBag;

    /**
     * 
     * @return
     *     returns String
     */
    public String getAuthInfo() {
        return this.authInfo;
    }

    /**
     * 
     * @param authInfo
     *     the value for the authInfo property
     */
    public void setAuthInfo(String authInfo) {
        this.authInfo = authInfo;
    }

    /**
     * 
     * @return
     *     returns KeyBag
     */
    public org.uddi.custody_v3.KeyBag getKeyBag() {
        return this.keyBag;
    }

    /**
     * 
     * @param keyBag
     *     the value for the keyBag property
     */
    public void setKeyBag(org.uddi.custody_v3.KeyBag keyBag) {
        this.keyBag = keyBag;
    }

}

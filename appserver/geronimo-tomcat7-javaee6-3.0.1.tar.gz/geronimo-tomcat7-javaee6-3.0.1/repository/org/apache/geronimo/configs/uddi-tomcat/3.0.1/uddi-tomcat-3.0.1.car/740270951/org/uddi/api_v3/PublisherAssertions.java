
package org.uddi.api_v3;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "publisherAssertions", namespace = "urn:uddi-org:api_v3")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "publisherAssertions", namespace = "urn:uddi-org:api_v3")
public class PublisherAssertions {

    @XmlElement(name = "publisherAssertion", namespace = "urn:uddi-org:api_v3")
    private List<org.uddi.api_v3.PublisherAssertion> publisherAssertion;

    /**
     * 
     * @return
     *     returns List<PublisherAssertion>
     */
    public List<org.uddi.api_v3.PublisherAssertion> getPublisherAssertion() {
        return this.publisherAssertion;
    }

    /**
     * 
     * @param publisherAssertion
     *     the value for the publisherAssertion property
     */
    public void setPublisherAssertion(List<org.uddi.api_v3.PublisherAssertion> publisherAssertion) {
        this.publisherAssertion = publisherAssertion;
    }

}

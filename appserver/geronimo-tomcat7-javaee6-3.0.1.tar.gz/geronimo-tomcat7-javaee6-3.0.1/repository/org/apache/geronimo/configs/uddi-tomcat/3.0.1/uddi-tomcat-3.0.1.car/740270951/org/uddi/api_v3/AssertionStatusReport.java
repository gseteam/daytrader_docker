
package org.uddi.api_v3;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "assertionStatusReport", namespace = "urn:uddi-org:api_v3")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "assertionStatusReport", namespace = "urn:uddi-org:api_v3")
public class AssertionStatusReport {

    @XmlElement(name = "assertionStatusItem", namespace = "urn:uddi-org:api_v3")
    private List<org.uddi.api_v3.AssertionStatusItem> assertionStatusItem;

    /**
     * 
     * @return
     *     returns List<AssertionStatusItem>
     */
    public List<org.uddi.api_v3.AssertionStatusItem> getAssertionStatusItem() {
        return this.assertionStatusItem;
    }

    /**
     * 
     * @param assertionStatusItem
     *     the value for the assertionStatusItem property
     */
    public void setAssertionStatusItem(List<org.uddi.api_v3.AssertionStatusItem> assertionStatusItem) {
        this.assertionStatusItem = assertionStatusItem;
    }

}
